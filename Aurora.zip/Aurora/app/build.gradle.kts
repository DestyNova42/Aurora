import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.aurora.alarm"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aurora.alarm"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "1.2.4"
    }

    // La clé de signature n'est jamais dans le dépôt : GitHub la fournit au moment
    // de compiler (Secrets AURORA_KEYSTORE et AURORA_KEYSTORE_PASSWORD).
    val keystorePath = System.getenv("AURORA_KEYSTORE_PATH")
    signingConfigs {
        if (keystorePath != null) {
            create("aurora") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("AURORA_KEYSTORE_PASSWORD")
                keyAlias = "aurora"
                keyPassword = System.getenv("AURORA_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // sans clé (compilation locale) : signature de test
            signingConfig = if (keystorePath != null) signingConfigs.getByName("aurora") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { compose = true }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.08.00")

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.2")

    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}
