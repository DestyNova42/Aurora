package com.aurora.alarm.data

import com.aurora.alarm.isFrench
import com.aurora.alarm.t
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZonedDateTime

/** Un réveil. days : 1 = lundi … 7 = dimanche (vide = une seule fois). */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Set<Int> = emptySet(),
    val label: String = "",
    val enabled: Boolean = true,
    val vibrate: Boolean = true,
    val ringtone: String? = null,
    val snooze: Boolean = false,
    val requirePassword: Boolean = true,
) {
    val repeating: Boolean get() = days.isNotEmpty()

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("hour", hour).put("minute", minute)
        .put("days", JSONArray(days.sorted()))
        .put("label", label).put("enabled", enabled).put("vibrate", vibrate)
        .put("ringtone", ringtone ?: "").put("snooze", snooze).put("requirePassword", requirePassword)

    /** Prochain déclenchement après [from]. */
    fun nextTrigger(from: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime {
        var t = from.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!t.isAfter(from)) t = t.plusDays(1)
        if (days.isNotEmpty()) {
            var guard = 0
            while (t.dayOfWeek.value !in days && guard < 8) {
                t = t.plusDays(1); guard++
            }
        }
        return t
    }

    companion object {
        fun fromJson(o: JSONObject): Alarm {
            val d = o.optJSONArray("days")
            val days = buildSet { if (d != null) for (i in 0 until d.length()) add(d.getInt(i)) }
            return Alarm(
                id = o.getInt("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = days,
                label = o.optString("label"),
                enabled = o.optBoolean("enabled", true),
                vibrate = o.optBoolean("vibrate", true),
                ringtone = o.optString("ringtone").ifBlank { null },
                snooze = o.optBoolean("snooze", false),
                requirePassword = o.optBoolean("requirePassword", true),
            )
        }
    }
}

/** Liste des réveils, enregistrée sur l'appareil, observable par l'interface. */
object AlarmStore {
    private var prefs: SharedPreferences? = null
    val alarms = mutableStateListOf<Alarm>()

    fun init(context: Context) {
        if (prefs != null) return
        // stockage protégé par l'appareil : lisible au démarrage, avant le premier déverrouillage
        val ctx = context.applicationContext.createDeviceProtectedStorageContext()
        runCatching { ctx.moveSharedPreferencesFrom(context.applicationContext, "alarms") }
        val p = ctx.getSharedPreferences("alarms", Context.MODE_PRIVATE)
        prefs = p
        alarms.clear()
        val arr = runCatching { JSONArray(p.getString("list", "[]")) }.getOrDefault(JSONArray())
        for (i in 0 until arr.length()) runCatching { alarms.add(Alarm.fromJson(arr.getJSONObject(i))) }
        sort()
    }

    private fun sort() {
        val sorted = alarms.sortedWith(compareBy({ it.hour }, { it.minute }))
        alarms.clear(); alarms.addAll(sorted)
    }

    private fun save() {
        val arr = JSONArray()
        alarms.forEach { arr.put(it.toJson()) }
        prefs?.edit()?.putString("list", arr.toString())?.apply()
    }

    fun get(id: Int): Alarm? = alarms.firstOrNull { it.id == id }

    fun newId(): Int = (alarms.maxOfOrNull { it.id } ?: 0) + 1

    fun upsert(a: Alarm) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = a else alarms.add(a)
        sort(); save()
    }

    fun delete(id: Int) {
        alarms.removeAll { it.id == id }
        save()
    }

    /** Le prochain réveil actif (et son heure). */
    fun next(now: ZonedDateTime = ZonedDateTime.now()): Pair<Alarm, ZonedDateTime>? =
        alarms.filter { it.enabled }.map { it to it.nextTrigger(now) }.minByOrNull { it.second.toEpochSecond() }
}

/** Texte des jours : « Tous les jours », « En semaine », « Lun, Mer »… */
fun daysText(days: Set<Int>): String = when {
    days.isEmpty() -> t("Une fois", "Once")
    days.size == 7 -> t("Tous les jours", "Every day")
    days == setOf(1, 2, 3, 4, 5) -> t("En semaine", "Weekdays")
    days == setOf(6, 7) -> t("Le week-end", "Weekends")
    else -> days.sorted().joinToString(", ") { SHORT_DAYS[it - 1] }
}

val SHORT_DAYS: List<String> get() = listOf(t("Lun", "Mon"), t("Mar", "Tue"), t("Mer", "Wed"), t("Jeu", "Thu"), t("Ven", "Fri"), t("Sam", "Sat"), t("Dim", "Sun"))
val LETTER_DAYS: List<String> get() = if (isFrench) listOf("L", "M", "M", "J", "V", "S", "D") else listOf("M", "T", "W", "T", "F", "S", "S")

/** « dans 7 h 12 min » */
fun untilText(t: ZonedDateTime, now: ZonedDateTime = ZonedDateTime.now()): String {
    val mins = ((t.toEpochSecond() - now.toEpochSecond()) / 60).coerceAtLeast(0) + 1
    val d = mins / (24 * 60)
    val h = (mins % (24 * 60)) / 60
    val m = mins % 60
    return buildString {
        append(t("dans ", "in "))
        if (d > 0) append(t("$d j ", "$d d "))
        if (h > 0) append("$h h ")
        if (d == 0L) append("$m min")
    }.trim()
}
