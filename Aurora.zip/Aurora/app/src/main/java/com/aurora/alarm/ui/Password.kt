package com.aurora.alarm.ui

import com.aurora.alarm.t
import androidx.activity.compose.BackHandler
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.alarm.data.AppPrefs
import kotlinx.coroutines.launch

/** Secousse horizontale (mauvais mot de passe). */
class Shake {
    val x = Animatable(0f)
    suspend fun run() {
        for (v in listOf(18f, -16f, 12f, -8f, 4f, 0f)) x.animateTo(v, spring(dampingRatio = 0.4f, stiffness = 4000f))
    }
}

/**
 * Saisie d'un code (points + pavé numérique) ou d'un mot de passe (clavier).
 * [onSubmit] reçoit le texte saisi et renvoie vrai s'il est accepté.
 */
@Composable
fun SecretEntry(
    kind: Int,
    light: Boolean,
    clearKey: Int,
    onSubmit: (String) -> Boolean,
) {
    var text by remember(clearKey) { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    val shake = remember { Shake() }
    val scope = rememberCoroutineScope()
    val fg = if (light) Color.White else Ac.Text
    val soft = if (light) Color.White.copy(alpha = 0.55f) else Ac.Soft
    val keyBg = if (light) Color.White.copy(alpha = 0.12f) else Ac.Surface
    // touches plus petites sur les écrans bas, pour que « Valider » reste visible
    val screenH = LocalConfiguration.current.screenHeightDp
    val key = ((screenH - 440) / 4).coerceIn(50, 72).dp

    fun submit() {
        if (text.isEmpty()) return
        if (!onSubmit(text)) {
            scope.launch { shake.run() }
            text = ""
        }
    }

    Column(
        Modifier.fillMaxWidth().offset { IntOffset(shake.x.value.dp.roundToPx(), 0) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (kind == 0) {
            // Points du code
            Row(Modifier.height(36.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.size(40.dp))
                Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    val n = maxOf(4, text.length)
                    for (i in 0 until n) {
                        val filled = i < text.length
                        if (filled && reveal) {
                            // chiffre visible tant qu'on appuie sur l'œil
                            // même largeur qu'un point, mais assez haut pour le chiffre entier
                            Box(Modifier.width(14.dp).height(32.dp), contentAlignment = Alignment.Center) {
                                Text(text[i].toString(), fontSize = 20.sp, lineHeight = 24.sp, color = fg, fontWeight = FontWeight.Medium, softWrap = false, maxLines = 1)
                            }
                        } else {
                            Box(
                                Modifier.size(14.dp).clip(CircleShape)
                                    .background(if (filled) fg else Color.Transparent)
                                    .border(1.5.dp, if (filled) fg else soft, CircleShape)
                            )
                        }
                    }
                }
                RevealEye(soft, visible = text.isNotEmpty()) { reveal = it }
            }
            Spacer(Modifier.height(18.dp))
            // Pavé : effacer à gauche du 0, valider (✓) à droite — tout tient à l'écran, sans défiler
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "<", "0", "OK")
            val ready = text.length >= 4
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        row.forEach { k ->
                            val bg: Brush = when (k) {
                                "<" -> SolidColor(Color.Transparent)
                                "OK" -> if (ready) Brush.linearGradient(listOf(Ac.Accent, Ac.Accent2)) else SolidColor(keyBg)
                                else -> SolidColor(keyBg)
                            }
                            Box(
                                Modifier.size(key).clip(CircleShape).background(bg)
                                    .clickable(enabled = k != "OK" || ready) {
                                        when (k) {
                                            "<" -> text = text.dropLast(1)
                                            "OK" -> submit()
                                            else -> if (text.length < 12) text += k
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                when (k) {
                                    "<" -> Icon(AIcons.Backspace, t("Effacer", "Delete"), tint = soft, modifier = Modifier.size(26.dp))
                                    "OK" -> Icon(
                                        AIcons.Check, t("Valider", "Confirm"),
                                        tint = if (ready) Color.White else soft.copy(alpha = 0.6f),
                                        modifier = Modifier.size(key * 0.42f),
                                    )
                                    else -> Text(k, fontSize = (key.value * 0.4f).sp, fontWeight = FontWeight.Light, color = fg)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val focus = remember { FocusRequester() }
            LaunchedEffect(clearKey) { runCatching { focus.requestFocus() } }
            BasicTextField(
                value = text, onValueChange = { text = it.take(40) }, singleLine = true,
                textStyle = TextStyle(fontSize = 22.sp, color = fg, textAlign = TextAlign.Center, letterSpacing = 4.sp),
                cursorBrush = SolidColor(Ac.Accent),
                visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done, autoCorrectEnabled = false),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(keyBg)
                    .padding(horizontal = 8.dp, vertical = 8.dp).focusRequester(focus),
                decorationBox = { inner ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // espace symétrique à l'œil pour garder le texte centré
                        Spacer(Modifier.size(40.dp))
                        Box(Modifier.weight(1f).padding(vertical = 8.dp), contentAlignment = Alignment.Center) { inner() }
                        RevealEye(soft, visible = text.isNotEmpty()) { reveal = it }
                    }
                },
            )
            Spacer(Modifier.height(18.dp))
            ConfirmButton(t("Valider", "Confirm"), enabled = text.length >= 4) { submit() }
        }
    }
}

@Composable
fun ConfirmButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.widthIn(max = 420.dp).fillMaxWidth().height(56.dp).clip(RoundedCornerShape(50))
            .background(if (enabled) Brush.horizontalGradient(listOf(Ac.Accent, Ac.Accent2)) else SolidColor(Ac.Soft.copy(alpha = 0.3f)))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
}

/** Définir ou changer le mot de passe (l'ancien est demandé d'abord). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PasswordScreen(onClose: () -> Unit) {
    // étapes : 0 = ancien, 1 = nouveau, 2 = confirmation
    var step by remember { mutableIntStateOf(if (AppPrefs.hasPassword) 0 else 1) }
    var kind by remember { mutableIntStateOf(AppPrefs.passwordKind) }
    var first by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var key by remember { mutableIntStateOf(0) }
    BackHandler(onBack = onClose)

    Column(Modifier.fillMaxSize().background(Ac.Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(AIcons.Back, t("Retour", "Back"), onClick = onClose)
        }
    val scroll = rememberScrollState()
    val imeOpen = WindowInsets.isImeVisible
    LaunchedEffect(imeOpen) {
        // clavier ouvert : on fait remonter le champ et le bouton au-dessus
        if (imeOpen) { kotlinx.coroutines.delay(250); scroll.animateScrollTo(scroll.maxValue) }
    }
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
        val minH = maxHeight
        Column(
            Modifier.fillMaxWidth().verticalScroll(scroll).heightIn(min = minH).padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(AIcons.Lock, null, tint = Ac.Accent, modifier = Modifier.size(30.dp))
            Text(
                when (step) { 0 -> t("Mot de passe actuel", "Current password"); 1 -> t("Nouveau mot de passe", "New password"); else -> t("Confirmez", "Confirm") },
                fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Ac.Text, modifier = Modifier.padding(top = 10.dp),
            )
            Text(
                error ?: when (step) {
                    0 -> t("Pour le modifier, saisissez d'abord l'actuel.", "To change it, enter the current one first.")
                    1 -> t("Il sera demandé pour arrêter la sonnerie. Au moins 4 caractères.", "It will be required to stop the alarm. At least 4 characters.")
                    else -> t("Saisissez-le une seconde fois.", "Enter it a second time.")
                },
                fontSize = 14.sp, color = if (error != null) Ac.Danger else Ac.Soft, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp, bottom = 14.dp),
            )
            if (step == 1) {
                Box(Modifier.widthIn(max = 360.dp)) {
                    ChoiceRow(listOf(0 to t("Code", "PIN"), 1 to t("Mot de passe", "Password")), kind) { kind = it; key++ }
                }
                Spacer(Modifier.height(10.dp))
            }
            SecretEntry(
                kind = if (step == 0) AppPrefs.passwordKind else kind,
                light = false,
                clearKey = key,
            ) { entered ->
                when (step) {
                    0 -> if (AppPrefs.check(entered)) { step = 1; error = null; key++; true } else { error = t("Mot de passe incorrect", "Wrong password"); false }
                    1 -> { first = entered; step = 2; error = null; key++; true }
                    else -> if (entered == first) {
                        AppPrefs.setPassword(entered, kind); onClose(); true
                    } else {
                        error = t("Les deux saisies sont différentes", "The two entries don't match"); step = 1; first = ""; key++; false
                    }
                }
            }
        }
        }
    }
}

/** Œil : maintenir appuyé affiche les caractères, relâcher les masque. */
@Composable
private fun RevealEye(tint: Color, visible: Boolean, onReveal: (Boolean) -> Unit) {
    val alpha by animateFloatAsState(if (visible) 1f else 0f, label = "eye")
    var held by remember { mutableStateOf(false) }
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .pointerInput(visible) {
                if (!visible) return@pointerInput
                detectTapGestures(onPress = {
                    held = true; onReveal(true)
                    tryAwaitRelease()
                    held = false; onReveal(false)
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (held) AIcons.Eye else AIcons.EyeOff, t("Afficher les caractères", "Show characters"),
            tint = if (held) Ac.Accent else tint,
            modifier = Modifier.size(22.dp).graphicsLayer { this.alpha = alpha },
        )
    }
}
