package com.aurora.alarm.ui

import com.aurora.alarm.t
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.alarm.data.AppPrefs

@Composable
fun SettingsScreen(onClose: () -> Unit, onPassword: () -> Unit) {
    val context = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResume { tick++ }
    BackHandler(onBack = onClose)
    var neverWarning by remember { mutableStateOf(false) }
    if (neverWarning) {
        AlertDialog(
            onDismissRequest = { neverWarning = false },
            containerColor = Ac.Surface,
            icon = { Icon(AIcons.Warning, null, tint = Ac.Danger, modifier = Modifier.size(30.dp)) },
            title = { Text(t("Désactiver l'arrêt automatique ?", "Turn off auto stop?"), color = Ac.Text) },
            text = {
                Text(
                    t("La sonnerie ne s'arrêtera plus jamais toute seule. Si vous oubliez votre mot de passe, " +
                        "elle sonnera jusqu'à ce que le téléphone soit éteint ou l'application désinstallée.",
                        "The alarm will never stop on its own. If you forget your password, " +
                            "it will ring until the phone is turned off or the app is uninstalled."),
                    color = Ac.Soft,
                )
            },
            confirmButton = {
                TextButton(onClick = { AppPrefs.changeAutoStop(0); neverWarning = false }) {
                    Text(t("Désactiver quand même", "Turn off anyway"), color = Ac.Danger, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = { TextButton(onClick = { neverWarning = false }) { Text(t("Annuler", "Cancel"), color = Ac.Text) } },
        )
    }

    Column(Modifier.fillMaxSize().background(Ac.Bg)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RoundIconButton(AIcons.Back, t("Retour", "Back"), onClick = onClose)
            Text(t("Réglages", "Settings"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ac.Text, modifier = Modifier.padding(start = 14.dp))
        }
        Column(
            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier.widthIn(max = 640.dp).fillMaxWidth()) {
                Card(title = t("Sécurité", "Security")) {
                    LinkLine(
                        if (AppPrefs.hasPassword) t("Changer le mot de passe", "Change password") else t("Définir le mot de passe", "Set password"),
                        if (!AppPrefs.hasPassword) t("Aucun", "None") else if (AppPrefs.passwordKind == 0) t("Code", "PIN") else t("Mot de passe", "Password"),
                        icon = AIcons.Lock, color = Ac.Text, onClick = onPassword,
                    )
                }
                Text(
                    t("L'ancien mot de passe est demandé pour le changer. Notez-le quelque part : sans lui, la sonnerie ne s'arrête qu'avec l'arrêt automatique.", "The current password is required to change it. Write it down somewhere: without it, the alarm only stops with auto stop."),
                    fontSize = 12.sp, color = Ac.Soft, modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 8.dp),
                )

                Card(title = t("Sonnerie", "Sound")) {
                    SwitchLine(t("Volume progressif", "Gradual volume"), t("Commence doucement puis monte en 30 s", "Starts softly and rises over 30 s"), AppPrefs.gradualVolume) { AppPrefs.changeGradual(it) }
                    Divider()
                    SwitchLine(t("Volume minimum garanti", "Guaranteed minimum volume"), t("Le volume du réveil passe à 80 % au moins pendant la sonnerie", "Alarm volume is raised to at least 80% while ringing"), AppPrefs.forceVolume) { AppPrefs.changeForce(it) }
                    Divider()
                    Text(t("Durée de la répétition", "Snooze length"), fontSize = 16.sp, color = Ac.Text, modifier = Modifier.padding(start = 18.dp, top = 14.dp))
                    ChoiceRow(listOf(5 to "5 min", 10 to "10 min", 15 to "15 min"), AppPrefs.snoozeMinutes) { AppPrefs.changeSnooze(it) }
                    Divider()
                    Text(t("Arrêt automatique", "Auto stop"), fontSize = 16.sp, color = Ac.Text, modifier = Modifier.padding(start = 18.dp, top = 14.dp))
                    Text(t("Sécurité si la sonnerie n'est pas arrêtée", "Safety net if the alarm isn't stopped"), fontSize = 13.sp, color = Ac.Soft, modifier = Modifier.padding(start = 18.dp))
                    ChoiceRow(listOf(15 to "15 min", 30 to "30 min", 60 to "1 h", 0 to t("Jamais", "Never")), AppPrefs.autoStop, danger = 0) {
                        if (it == 0 && AppPrefs.autoStop != 0) neverWarning = true else AppPrefs.changeAutoStop(it)
                    }
                    if (AppPrefs.autoStop == 0) {
                        Row(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 14.dp), verticalAlignment = Alignment.Top) {
                            Icon(AIcons.Warning, null, tint = Ac.Danger, modifier = Modifier.padding(top = 1.dp).size(18.dp))
                            Text(
                                t("Sans arrêt automatique, un mot de passe oublié signifie une sonnerie sans fin.",
                                    "Without auto stop, a forgotten password means an alarm that never ends."),
                                fontSize = 13.sp, color = Ac.Danger, modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }

                Card(title = t("Apparence", "Appearance")) {
                    ChoiceRow(listOf(0 to t("Système", "System"), 1 to t("Clair", "Light"), 2 to t("Sombre", "Dark")), AppPrefs.themeMode) { AppPrefs.changeTheme(it) }
                }

                Card(title = t("Fiabilité", "Reliability")) {
                    check(tick >= 0)
                    LinkLine("Notifications", if (notificationsAllowed(context)) t("Autorisées", "Allowed") else t("Bloquées", "Blocked")) { openNotificationSettings(context) }
                    Divider()
                    LinkLine(t("Affichage plein écran", "Full-screen display"), if (fullScreenAllowed(context)) t("Autorisé", "Allowed") else t("Refusé", "Denied")) { openFullScreenSettings(context) }
                    Divider()
                    LinkLine(t("Optimisation de la batterie", "Battery optimization"), if (batteryUnrestricted(context)) t("Désactivée", "Off") else t("Active", "On")) { openBatterySettings(context) }
                }
                Text(
                    t("Pour un réveil fiable, laissez Aurora sans restriction de batterie. Sur Samsung : Paramètres › Batterie › Limites d'utilisation en arrière-plan, et retirez Aurora des applications en veille.", "For a reliable alarm, leave Aurora unrestricted in battery settings. On Samsung: Settings › Battery › Background usage limits, and remove Aurora from sleeping apps."),
                    fontSize = 12.sp, color = Ac.Soft, modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 8.dp),
                )
                Spacer(Modifier.height(30.dp))
            }
        }
    }
}

fun batteryUnrestricted(context: Context): Boolean =
    (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(context.packageName)

@SuppressLint("BatteryLife")
fun openBatterySettings(context: Context) {
    val i = if (!batteryUnrestricted(context)) {
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + context.packageName))
    } else {
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    }
    runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
