package com.aurora.alarm.ui

import com.aurora.alarm.t
import android.app.Activity
import java.io.File
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.gestures.detectTapGestures
import android.provider.OpenableColumns
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.alarm.alarm.Scheduler
import com.aurora.alarm.alarm.SoundPreview
import com.aurora.alarm.data.Alarm
import com.aurora.alarm.data.AlarmStore
import com.aurora.alarm.data.AppPrefs
import com.aurora.alarm.data.LETTER_DAYS
import com.aurora.alarm.data.untilText
import kotlinx.coroutines.flow.distinctUntilChanged
import java.time.LocalTime
import kotlin.math.abs

@Composable
fun EditScreen(initial: Alarm?, onClose: () -> Unit, onSetPassword: () -> Unit) {
    val context = LocalContext.current
    val start = remember {
        initial ?: LocalTime.now().plusHours(1).let {
            Alarm(id = AlarmStore.newId(), hour = it.hour, minute = 0, requirePassword = true)
        }
    }
    var hour by remember { mutableIntStateOf(start.hour) }
    var minute by remember { mutableIntStateOf(start.minute) }
    var days by remember { mutableStateOf(start.days) }
    var label by remember { mutableStateOf(start.label) }
    var vibrate by remember { mutableStateOf(start.vibrate) }
    var ringtone by remember { mutableStateOf(start.ringtone) }
    var snooze by remember { mutableStateOf(start.snooze) }
    var requirePassword by remember { mutableStateOf(start.requirePassword) }
    // 0 = saisie de l'heure, 1 = des minutes, null = roues
    var typing by remember { mutableStateOf<Int?>(null) }
    var soundChoice by remember { mutableStateOf(false) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importSound(context, uri)?.let { ringtone = it }
    }

    BackHandler { if (typing != null) typing = null else onClose() }
    // les touches de volume font entendre la sonnerie choisie ici
    SideEffect { SoundPreview.editing = ringtone }
    DisposableEffect(Unit) {
        SoundPreview.inEditor = true
        onDispose { SoundPreview.inEditor = false; SoundPreview.stop() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            ringtone = uri?.toString()
        }
    }
    val ringtoneName = remember(ringtone) {
        if (ringtone?.startsWith("file:") == true) return@remember soundName(ringtone!!)
        val uri = ringtone?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        runCatching { RingtoneManager.getRingtone(context, uri)?.getTitle(context) }.getOrNull()
            ?.let { if (ringtone == null) t("Par défaut", "Default") else it } ?: t("Par défaut", "Default")
    }

    fun current() = start.copy(
        hour = hour, minute = minute, days = days, label = label.trim(), vibrate = vibrate,
        ringtone = ringtone, snooze = snooze, requirePassword = requirePassword, enabled = true,
    )

    Column(Modifier.fillMaxSize().background(Ac.Bg)) {
        // Barre du haut
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RoundIconButton(AIcons.Back, t("Retour", "Back"), onClick = onClose)
            Text(
                if (initial == null) t("Nouveau réveil", "New alarm") else t("Modifier", "Edit"),
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ac.Text,
                modifier = Modifier.weight(1f).padding(start = 14.dp),
            )
            if (initial != null) {
                RoundIconButton(AIcons.Delete, t("Supprimer", "Delete"), tint = Ac.Danger) {
                    Scheduler.cancel(context, start.id)
                    Scheduler.cancelSnooze(context, start.id)
                    AlarmStore.delete(start.id)
                    onClose()
                }
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(Modifier.widthIn(max = 560.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                // Roues des heures et des minutes
                Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(22.dp)).background(Ac.Surface))
                    if (typing == null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Wheel(24, hour, onTap = { typing = 0 }) { hour = it }
                            Text(":", fontSize = 52.sp, fontWeight = FontWeight.Light, color = Ac.Text, modifier = Modifier.padding(horizontal = 6.dp, vertical = 0.dp).padding(bottom = 6.dp))
                            Wheel(60, minute, onTap = { typing = 1 }) { minute = it }
                        }
                    } else {
                        // Saisie au clavier numérique (appui sur l'heure ou les minutes)
                        TimeTyping(hour, minute, startOnMinutes = typing == 1) { h, m ->
                            if (h != null) hour = h
                            if (m != null) minute = m
                            typing = null
                        }
                    }
                }
                Text(
                    t("Sonne ${untilText(current().nextTrigger())}", "Rings ${untilText(current().nextTrigger())}"),
                    fontSize = 14.sp, color = Ac.Soft, modifier = Modifier.padding(top = 6.dp),
                )

                // Jours
                Row(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    LETTER_DAYS.forEachIndexed { i, l ->
                        val d = i + 1
                        val on = d in days
                        val bg by animateColorAsState(if (on) Ac.Accent else Ac.Surface, label = "day")
                        Box(
                            Modifier.weight(1f).padding(horizontal = 3.dp).aspectRatio(1f).widthIn(max = 52.dp)
                                .clip(CircleShape).background(bg)
                                .clickable { days = if (on) days - d else days + d },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(l, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.White else Ac.Soft)
                        }
                    }
                }

                Card {
                    // Nom
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t("Nom", "Name"), fontSize = 16.sp, color = Ac.Text, modifier = Modifier.width(90.dp))
                        BasicTextField(
                            label, { label = it.take(40) }, singleLine = true,
                            textStyle = TextStyle(fontSize = 16.sp, color = Ac.Text),
                            cursorBrush = SolidColor(Ac.Accent),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                Box {
                                    if (label.isEmpty()) Text(t("Réveil", "Alarm"), fontSize = 16.sp, color = Ac.Soft)
                                    inner()
                                }
                            },
                        )
                    }
                    Divider()
                    LinkLine(t("Sonnerie", "Sound"), ringtoneName) { soundChoice = true }
                    if (soundChoice) SoundChoiceDialog(
                        onDismiss = { soundChoice = false },
                        onImport = { soundChoice = false; runCatching { importer.launch(arrayOf("audio/*")) } },
                    ) {
                        soundChoice = false
                        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, t("Sonnerie du réveil", "Alarm sound"))
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtone?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        runCatching { picker.launch(i) }
                    }
                    Divider()
                    SwitchLine("Vibration", null, vibrate) { vibrate = it }
                    Divider()
                    SwitchLine(t("Répétition", "Snooze"), t("Permet de repousser de ${AppPrefs.snoozeMinutes} min", "Lets you postpone by ${AppPrefs.snoozeMinutes} min"), snooze) { snooze = it }
                }

                Card(title = t("Arrêt", "Stopping")) {
                    if (AppPrefs.hasPassword) {
                        SwitchLine(
                            t("Mot de passe pour arrêter", "Password to stop"),
                            if (requirePassword) t("La sonnerie ne s'arrête qu'avec votre mot de passe", "The alarm only stops with your password") else t("Un simple bouton arrête la sonnerie", "A simple button stops the alarm"),
                            requirePassword,
                        ) { requirePassword = it }
                    } else {
                        LinkLine(t("Définir le mot de passe", "Set password"), t("Aucun", "None"), icon = AIcons.Lock, color = Ac.Accent, onClick = onSetPassword)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        // Enregistrer
        Box(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.widthIn(max = 560.dp).fillMaxWidth().height(56.dp).clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Ac.Accent, Ac.Accent2)))
                    .clickable {
                        val a = current()
                        AlarmStore.upsert(a)
                        Scheduler.cancelSnooze(context, a.id)
                        Scheduler.schedule(context, a)
                        showUntilToast(context, a)
                        onClose()
                    },
                contentAlignment = Alignment.Center,
            ) { Text(t("Enregistrer", "Save"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

/** Roue verticale infinie (heures ou minutes), qui s'aimante sur la valeur centrale. */
@Composable
private fun Wheel(count: Int, value: Int, onTap: () -> Unit, onValue: (Int) -> Unit) {
    val itemH = 64.dp
    val rows = 3
    val base = count * 400
    val state = rememberLazyListState(initialFirstVisibleItemIndex = base + value - rows / 2)
    val fling = rememberSnapFlingBehavior(state)
    val density = LocalDensity.current
    val itemPx = with(density) { itemH.toPx() }

    LaunchedEffect(state) {
        snapshotFlow {
            val info = state.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2f
            info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2f - center) }?.index
        }.distinctUntilChanged().collect { idx -> if (idx != null) onValue(idx % count) }
    }
    // valeur changée au clavier : la roue rejoint la nouvelle valeur par le chemin le plus court
    LaunchedEffect(value) {
        val info = state.layoutInfo
        val center = (info.viewportStartOffset + info.viewportEndOffset) / 2f
        val cur = info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2f - center) }?.index ?: return@LaunchedEffect
        var diff = ((value - cur % count) % count + count) % count
        if (diff > count / 2) diff -= count
        if (diff != 0) state.scrollToItem(cur + diff - rows / 2)
    }

    LazyColumn(
        state = state,
        flingBehavior = fling,
        modifier = Modifier.width(110.dp).height(itemH * rows)
            .pointerInput(Unit) { detectTapGestures { onTap() } },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(count * 800) { i ->
            Box(
                Modifier.height(itemH).fillMaxWidth().graphicsLayer {
                    // atténuation et léger rétrécissement loin du centre
                    val info = state.layoutInfo
                    val center = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                    val me = info.visibleItemsInfo.firstOrNull { it.index == i }
                    val dist = if (me == null) 1f else (abs(me.offset + me.size / 2f - center) / itemPx).coerceIn(0f, 1.5f)
                    alpha = 1f - dist * 0.6f
                    val s = 1f - dist * 0.18f
                    scaleX = s; scaleY = s
                },
                contentAlignment = Alignment.Center,
            ) {
                Text("%02d".format(i % count), fontSize = 52.sp, fontWeight = FontWeight.Light, color = Ac.Text)
            }
        }
    }
}

/** Saisie de l'heure au clavier numérique : 2 chiffres pour l'heure, puis 2 pour les minutes. */
@Composable
private fun TimeTyping(hour: Int, minute: Int, startOnMinutes: Boolean, onDone: (Int?, Int?) -> Unit) {
    var h by remember { mutableStateOf(TextFieldValue("%02d".format(hour), TextRange(0, 2))) }
    var m by remember { mutableStateOf(TextFieldValue("%02d".format(minute), TextRange(0, 2))) }
    val hf = remember { FocusRequester() }
    val mf = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(Unit) { runCatching { if (startOnMinutes) mf.requestFocus() else hf.requestFocus() } }
    fun finish() {
        keyboard?.hide()
        onDone(h.text.toIntOrNull()?.coerceIn(0, 23), m.text.toIntOrNull()?.coerceIn(0, 59))
    }
    val style = TextStyle(fontSize = 52.sp, fontWeight = FontWeight.Light, color = Ac.Text, textAlign = TextAlign.Center)
    Row(Modifier.height(64.dp * 3), verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(
            value = h,
            onValueChange = { v ->
                val d = v.text.filter { it.isDigit() }.take(2)
                h = TextFieldValue(d, TextRange(d.length))
                // 2 chiffres (ou un chiffre qui ne peut pas commencer une heure > 23) : on passe aux minutes
                if (d.length == 2 || (d.length == 1 && d[0] > '2')) {
                    if (d.length == 1) h = TextFieldValue("0$d", TextRange(2))
                    m = m.copy(selection = TextRange(0, m.text.length))
                    runCatching { mf.requestFocus() }
                }
            },
            singleLine = true, textStyle = style, cursorBrush = SolidColor(Ac.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { runCatching { mf.requestFocus() } }),
            modifier = Modifier.width(110.dp).focusRequester(hf),
        )
        Text(":", fontSize = 52.sp, fontWeight = FontWeight.Light, color = Ac.Text, modifier = Modifier.padding(horizontal = 6.dp).padding(bottom = 6.dp))
        BasicTextField(
            value = m,
            onValueChange = { v ->
                val d = v.text.filter { it.isDigit() }.take(2)
                m = TextFieldValue(d, TextRange(d.length))
                if (d.length == 2) finish()
            },
            singleLine = true, textStyle = style, cursorBrush = SolidColor(Ac.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { finish() }),
            modifier = Modifier.width(110.dp).focusRequester(mf),
        )
    }
}

/** Choix de la sonnerie : celles du téléphone ou une musique importée. */
@Composable
private fun SoundChoiceDialog(onDismiss: () -> Unit, onImport: () -> Unit, onSystem: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ac.Surface,
        title = { Text(t("Sonnerie", "Sound"), color = Ac.Text) },
        text = {
            Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Ac.Surface2)) {
                LinkLine(t("Sonneries du téléphone", "Phone sounds"), null, icon = AIcons.Alarm, onClick = onSystem)
                Divider()
                LinkLine(t("Importer une musique", "Import music"), null, icon = AIcons.Music, onClick = onImport)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("Annuler", "Cancel"), color = Ac.Accent) } },
    )
}

/** Copie la musique choisie dans l'appli (elle reste disponible même si l'original est déplacé). */
private fun importSound(context: Context, uri: Uri): String? = runCatching {
    var name = "musique"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) name = c.getString(0) ?: name
    }
    val safe = name.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "_").take(80)
    // stockage lisible au démarrage, avant le premier déverrouillage
    val dir = File(context.createDeviceProtectedStorageContext().filesDir, "sounds").apply { mkdirs() }
    val out = File(dir, safe)
    context.contentResolver.openInputStream(uri)!!.use { input -> out.outputStream().use { input.copyTo(it) } }
    Uri.fromFile(out).toString()
}.getOrNull()

private fun soundName(fileUri: String): String =
    Uri.parse(fileUri).lastPathSegment?.substringBeforeLast('.') ?: t("Musique", "Music")
