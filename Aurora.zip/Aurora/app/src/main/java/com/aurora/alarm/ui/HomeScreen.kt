package com.aurora.alarm.ui

import com.aurora.alarm.t
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.alarm.RingActivity
import com.aurora.alarm.alarm.AlarmService
import com.aurora.alarm.alarm.Scheduler
import com.aurora.alarm.data.Alarm
import com.aurora.alarm.data.AlarmStore
import com.aurora.alarm.data.AppPrefs
import com.aurora.alarm.data.daysText
import com.aurora.alarm.data.untilText
import kotlinx.coroutines.delay
import java.time.ZonedDateTime

@Composable
fun HomeScreen(onEdit: (Alarm?) -> Unit, onSettings: () -> Unit, onSetPassword: () -> Unit) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { now = ZonedDateTime.now(); delay(20_000) }
    }
    var resumeTick by remember { mutableStateOf(0) }
    LifecycleResume { resumeTick++ }

    Box(Modifier.fillMaxSize().background(Ac.Bg)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 120.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item {
                Column(Modifier.widthIn(max = 640.dp).fillMaxWidth().statusBarsPadding().padding(top = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t("Réveils", "Alarms"), fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = Ac.Text, modifier = Modifier.weight(1f))
                        RoundIconButton(AIcons.Settings, t("Réglages", "Settings"), onClick = onSettings)
                    }
                    val next = AlarmStore.next(now)
                    Text(
                        if (next == null) t("Aucun réveil actif", "No active alarm") else t("Prochain réveil ${untilText(next.second, now)}", "Next alarm ${untilText(next.second, now)}"),
                        fontSize = 15.sp, color = Ac.Soft, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp),
                    )
                }
            }
            // Avertissements utiles (mot de passe, autorisations)
            item {
                Column(Modifier.widthIn(max = 640.dp).fillMaxWidth()) {
                    // relu à chaque retour dans l'appli (autorisations accordées entre-temps)
                    check(resumeTick >= 0)
                    if (AlarmService.ringing.value != null) {
                        Notice(t("Un réveil sonne", "An alarm is ringing"), t("Saisissez votre mot de passe pour l'arrêter.", "Enter your password to stop it."), t("Ouvrir", "Open")) {
                            context.startActivity(
                                Intent(context, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    .putExtra(Scheduler.EXTRA_ID, AlarmService.ringing.value ?: -1)
                            )
                        }
                    }
                    if (!AppPrefs.hasPassword) {
                        Notice(
                            t("Choisissez votre mot de passe", "Choose your password"),
                            t("Il sera demandé pour arrêter la sonnerie.", "It will be required to stop the alarm."),
                            t("Définir", "Set"), onSetPassword,
                        )
                    }
                    if (!fullScreenAllowed(context)) {
                        Notice(
                            t("Autoriser l'affichage plein écran", "Allow full-screen display"),
                            t("Pour que l'écran du réveil s'allume, même verrouillé.", "So the alarm screen turns on, even when locked."),
                            t("Autoriser", "Allow"),
                        ) { openFullScreenSettings(context) }
                    }
                    if (!notificationsAllowed(context)) {
                        Notice(
                            t("Autoriser les notifications", "Allow notifications"),
                            t("Sans elles, Android peut bloquer la sonnerie.", "Without them, Android may block the alarm."),
                            t("Ouvrir", "Open"),
                        ) { openNotificationSettings(context) }
                    }
                }
            }
            if (AlarmStore.alarms.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 90.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(AIcons.Alarm, null, tint = Ac.Soft.copy(alpha = 0.5f), modifier = Modifier.size(64.dp))
                        Text(t("Pas encore de réveil", "No alarms yet"), fontSize = 18.sp, color = Ac.Text, modifier = Modifier.padding(top = 14.dp))
                        Text(t("Touchez + pour en créer un.", "Tap + to create one."), fontSize = 14.sp, color = Ac.Soft, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            items(AlarmStore.alarms, key = { it.id }) { a ->
                AlarmCard(a, now, onClick = { onEdit(a) }) { on ->
                    val updated = a.copy(enabled = on)
                    AlarmStore.upsert(updated)
                    Scheduler.schedule(context, updated)
                    if (!on) Scheduler.cancelSnooze(context, updated.id)
                    if (on) showUntilToast(context, updated)
                }
            }
        }
        // Bouton d'ajout
        Box(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 22.dp)
                .size(68.dp).shadow(18.dp, CircleShape, spotColor = Ac.Accent)
                .clip(CircleShape).background(Brush.linearGradient(listOf(Ac.Accent, Ac.Accent2)))
                .clickable { onEdit(null) },
            contentAlignment = Alignment.Center,
        ) { Icon(AIcons.Add, t("Nouveau réveil", "New alarm"), tint = Color.White, modifier = Modifier.size(32.dp)) }
    }
}

@Composable
private fun AlarmCard(a: Alarm, now: ZonedDateTime, onClick: () -> Unit, onToggle: (Boolean) -> Unit) {
    val alpha by animateFloatAsState(if (a.enabled) 1f else 0.45f, label = "cardAlpha")
    val bg by animateColorAsState(if (a.enabled) Ac.Surface else Ac.Surface.copy(alpha = 0.6f), label = "cardBg")
    Row(
        Modifier.widthIn(max = 640.dp).fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(26.dp)).background(bg)
            .clickable(onClick = onClick).padding(start = 22.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).alpha(alpha)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("%02d:%02d".format(a.hour, a.minute), fontSize = 52.sp, fontWeight = FontWeight.Light, color = Ac.Text, letterSpacing = (-1).sp)
                if (a.requirePassword && AppPrefs.hasPassword) {
                    Icon(AIcons.Lock, t("Mot de passe", "Password"), tint = Ac.Accent, modifier = Modifier.padding(start = 10.dp, bottom = 14.dp).size(16.dp))
                }
            }
            val sub = buildString {
                if (a.label.isNotBlank()) append(a.label).append(" · ")
                append(daysText(a.days))
                if (a.enabled) append(" · ").append(untilText(a.nextTrigger(now), now))
            }
            Text(sub, fontSize = 14.sp, color = Ac.Soft, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        AuroraSwitch(a.enabled, onToggle)
    }
}

@Composable
private fun Notice(title: String, text: String, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(20.dp)).background(Ac.Accent.copy(alpha = 0.13f))
            .padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Ac.Text)
            Text(text, fontSize = 13.sp, color = Ac.Soft)
        }
        Spacer(Modifier.size(8.dp))
        Box(
            Modifier.clip(RoundedCornerShape(50)).background(Ac.Accent).clickable(onClick = onAction).padding(horizontal = 14.dp, vertical = 8.dp)
        ) { Text(action, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

fun showUntilToast(context: Context, a: Alarm) {
    android.widget.Toast.makeText(context, t("Réveil ${untilText(a.nextTrigger())}", "Alarm ${untilText(a.nextTrigger())}"), android.widget.Toast.LENGTH_SHORT).show()
}

fun fullScreenAllowed(context: Context): Boolean =
    Build.VERSION.SDK_INT < 34 || context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

fun notificationsAllowed(context: Context): Boolean =
    context.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

fun openFullScreenSettings(context: Context) {
    val i = if (Build.VERSION.SDK_INT >= 34) {
        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + context.packageName))
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))
    }
    runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

fun openNotificationSettings(context: Context) {
    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
    runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
