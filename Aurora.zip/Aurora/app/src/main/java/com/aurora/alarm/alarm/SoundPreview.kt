package com.aurora.alarm.alarm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import com.aurora.alarm.data.AlarmStore

/**
 * Aperçu de la sonnerie avec les touches de volume :
 * « + » et « - » règlent le volume du réveil en faisant entendre la sonnerie ; un toucher l'arrête.
 */
object SoundPreview {
    private var player: MediaPlayer? = null

    /** Sonnerie à prévisualiser : celle du réveil en cours de modification, sinon celle du prochain réveil. */
    var editing: String? = null
    var inEditor = false

    val playing: Boolean get() = player != null

    fun play(ctx: Context) {
        if (player != null) return
        val sound = if (inEditor) editing else AlarmStore.next()?.first?.ringtone
        val uri = sound?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: return
        val mp = MediaPlayer()
        val ok = runCatching {
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            mp.setDataSource(ctx, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
        }.isSuccess
        if (ok) player = mp else mp.release()
    }

    fun stop() {
        player?.let { runCatching { it.stop() }; it.release() }
        player = null
    }
}
