package com.aurora.alarm.ui

import com.aurora.alarm.t
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.alarm.data.Alarm
import com.aurora.alarm.data.AppPrefs
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Écran de sonnerie : heure, aube animée, et saisie du mot de passe pour arrêter. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RingScreen(alarm: Alarm?, onStop: () -> Unit, onSnooze: () -> Unit) {
    BackHandler { /* le retour n'arrête pas le réveil */ }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    var message by remember { mutableStateOf<String?>(null) }

    val pulse = rememberInfiniteTransition(label = "dawn")
    val glow by pulse.animateFloat(0.75f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Reverse), label = "glow")

    val scroll = rememberScrollState()
    val imeOpen = WindowInsets.isImeVisible
    LaunchedEffect(imeOpen) {
        // clavier ouvert : on fait remonter le champ et le bouton au-dessus
        if (imeOpen) { kotlinx.coroutines.delay(250); scroll.animateScrollTo(scroll.maxValue) }
    }
    val needPassword = AppPrefs.hasPassword && (alarm?.requirePassword != false)

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0F1124), Color(0xFF241B3D), Color(0xFF4A2338))))) {
        // Soleil levant qui respire en bas de l'écran
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height * 1.02f)
            val r = size.width * 0.95f * glow
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFF8A3D).copy(alpha = 0.55f), Color(0xFFFF5E7E).copy(alpha = 0.18f), Color.Transparent), c, r), r, c)
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().verticalScroll(scroll)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Spacer(Modifier.height(28.dp))
            Text(
                now.format(DateTimeFormatter.ofPattern("HH:mm")),
                fontSize = 96.sp, fontWeight = FontWeight.Thin, color = Color.White, letterSpacing = (-2).sp,
            )
            Text(
                now.format(DateTimeFormatter.ofPattern(t("EEEE d MMMM", "EEEE, MMMM d"), Locale.getDefault())).replaceFirstChar { it.titlecase(Locale.getDefault()) },
                fontSize = 17.sp, color = Color.White.copy(alpha = 0.7f),
            )
            if (!alarm?.label.isNullOrBlank()) {
                Text(alarm!!.label, fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp))
            }
            Spacer(Modifier.height(34.dp))

            if (needPassword) {
                Text(
                    message ?: if (AppPrefs.passwordKind == 0) t("Saisissez votre code pour arrêter", "Enter your PIN to stop") else t("Saisissez votre mot de passe pour arrêter", "Enter your password to stop"),
                    fontSize = 15.sp, color = if (message != null) Color(0xFFFF8A8A) else Color.White.copy(alpha = 0.75f),
                    modifier = Modifier.padding(bottom = 18.dp),
                )
                SecretEntry(kind = AppPrefs.passwordKind, light = true, clearKey = 0) { entered ->
                    if (AppPrefs.check(entered)) { onStop(); true } else { message = t("Mot de passe incorrect", "Wrong password"); false }
                }
            } else {
                Box(Modifier.widthIn(max = 420.dp).fillMaxWidth()) { ConfirmButton(t("Arrêter", "Stop"), onClick = onStop) }
            }

            if (alarm?.snooze == true) {
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.12f)).clickable(onClick = onSnooze)
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                ) { Text(t("Répéter dans ${AppPrefs.snoozeMinutes} min", "Snooze for ${AppPrefs.snoozeMinutes} min"), color = Color.White, fontSize = 15.sp) }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}
