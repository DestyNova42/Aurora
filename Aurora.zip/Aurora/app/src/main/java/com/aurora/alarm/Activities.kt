package com.aurora.alarm

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.aurora.alarm.alarm.AlarmService
import com.aurora.alarm.alarm.Scheduler
import com.aurora.alarm.alarm.SoundPreview
import com.aurora.alarm.data.Alarm
import com.aurora.alarm.data.AlarmStore
import com.aurora.alarm.data.AppPrefs
import com.aurora.alarm.ui.Ac
import com.aurora.alarm.ui.AuroraTheme
import com.aurora.alarm.ui.EditScreen
import com.aurora.alarm.ui.HomeScreen
import com.aurora.alarm.ui.PasswordScreen
import com.aurora.alarm.ui.RingScreen
import com.aurora.alarm.ui.SettingsScreen

class AuroraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching { AlarmStore.init(this) }
        runCatching { AppPrefs.init(this) }
        AlarmService.ensureChannels(this)
    }
}

/** Écrans de l'application. */
private sealed interface Screen {
    data object Home : Screen
    data class Edit(val alarm: Alarm?) : Screen
    data object Settings : Screen
    data class Password(val back: Screen) : Screen
}

class MainActivity : ComponentActivity() {
    // Touches de volume : réglent le volume du réveil et font entendre la sonnerie
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                am.adjustStreamVolume(android.media.AudioManager.STREAM_ALARM, android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
                if (AlarmService.ringing.value == null) SoundPreview.play(this)
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                am.adjustStreamVolume(android.media.AudioManager.STREAM_ALARM, android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
                // l'aperçu continue : on entend le volume baisser
                if (AlarmService.ringing.value == null) SoundPreview.play(this)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    // toucher ou faire défiler l'écran coupe l'aperçu
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (SoundPreview.playing && ev.actionMasked == android.view.MotionEvent.ACTION_DOWN) SoundPreview.stop()
        return super.dispatchTouchEvent(ev)
    }

    override fun onPause() {
        SoundPreview.stop()
        super.onPause()
    }

    private val askNotif = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlarmStore.init(this)
        AppPrefs.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        // reprogramme tout à l'ouverture (sécurité après une mise à jour)
        Scheduler.rescheduleAll(this)

        setContent {
            AuroraTheme {
                val dark = Ac.dark
                LaunchedEffect(dark) {
                    enableEdgeToEdge(
                        statusBarStyle = if (dark) SystemBarStyle.dark(0) else SystemBarStyle.light(0, 0),
                        navigationBarStyle = if (dark) SystemBarStyle.dark(0) else SystemBarStyle.light(0, 0),
                    )
                }
                var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                AnimatedContent(screen, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "screen") { s ->
                    when (s) {
                        Screen.Home -> HomeScreen(
                            onEdit = { screen = Screen.Edit(it) },
                            onSettings = { screen = Screen.Settings },
                            onSetPassword = { screen = Screen.Password(Screen.Home) },
                        )
                        is Screen.Edit -> EditScreen(
                            s.alarm,
                            onClose = { screen = Screen.Home },
                            onSetPassword = { screen = Screen.Password(s) },
                        )
                        Screen.Settings -> SettingsScreen(
                            onClose = { screen = Screen.Home },
                            onPassword = { screen = Screen.Password(Screen.Settings) },
                        )
                        is Screen.Password -> PasswordScreen(onClose = { screen = s.back })
                    }
                }
            }
        }
    }
}

/** Écran de sonnerie, par-dessus l'écran verrouillé. */
class RingActivity : ComponentActivity() {
    private var alarmId by mutableStateOf(-1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlarmStore.init(this)
        AppPrefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(0), navigationBarStyle = SystemBarStyle.dark(0))
        alarmId = intent.getIntExtra(Scheduler.EXTRA_ID, AlarmService.ringing.value ?: -1)

        setContent {
            AuroraTheme {
                val ringing = AlarmService.ringing.value
                LaunchedEffect(ringing) {
                    if (ringing == null) {
                        // plus rien ne sonne (arrêt automatique…) : on ferme
                        kotlinx.coroutines.delay(400)
                        if (AlarmService.ringing.value == null) finish()
                    } else {
                        alarmId = ringing
                    }
                }
                RingScreen(
                    alarm = AlarmStore.get(alarmId),
                    onStop = { AlarmService.stop(this); finish() },
                    onSnooze = { AlarmService.snooze(this); finish() },
                )
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        alarmId = intent.getIntExtra(Scheduler.EXTRA_ID, alarmId)
    }

    // Les touches de volume ne coupent pas le réveil
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE -> true
        else -> super.onKeyDown(keyCode, event)
    }
}
