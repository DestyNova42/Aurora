package com.aurora.alarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.aurora.alarm.data.AlarmStore
import com.aurora.alarm.data.AppPrefs

/** Heure du réveil : lance la sonnerie et prépare le prochain déclenchement. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmStore.init(context)
        AppPrefs.init(context)
        val id = intent.getIntExtra(Scheduler.EXTRA_ID, -1)
        val snooze = intent.getBooleanExtra(Scheduler.EXTRA_SNOOZE, false)
        val alarm = AlarmStore.get(id) ?: return
        if (!snooze) {
            if (alarm.repeating) {
                Scheduler.schedule(context, alarm)
            } else {
                // réveil unique : il se désactive une fois sonné
                AlarmStore.upsert(alarm.copy(enabled = false))
            }
        }
        val svc = Intent(context, AlarmService::class.java).putExtra(Scheduler.EXTRA_ID, id)
        ContextCompat.startForegroundService(context, svc)
    }
}

/** Après un redémarrage, un changement d'heure ou une mise à jour : on reprogramme tout. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AppPrefs.init(context)
        Scheduler.rescheduleAll(context)
    }
}
