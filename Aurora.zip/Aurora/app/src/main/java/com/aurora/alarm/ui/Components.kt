package com.aurora.alarm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuroraSwitch(checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true) {
    Switch(
        checked = checked, onCheckedChange = onChange, enabled = enabled,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = Ac.Accent, checkedBorderColor = Color.Transparent,
            uncheckedThumbColor = Ac.Soft, uncheckedTrackColor = Ac.Surface2, uncheckedBorderColor = Color.Transparent,
        ),
    )
}

/** Bloc arrondi contenant des lignes de réglage. */
@Composable
fun Card(title: String? = null, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp)) {
        if (title != null) {
            Text(title.uppercase(), fontSize = 12.sp, letterSpacing = 1.sp, color = Ac.Soft, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Ac.Surface)) { content() }
    }
}

@Composable
fun Divider() {
    Box(Modifier.padding(start = 18.dp).fillMaxWidth().height(0.6.dp).background(Ac.Line))
}

@Composable
fun SwitchLine(title: String, subtitle: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = if (enabled) Ac.Text else Ac.Soft)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = Ac.Soft)
        }
        AuroraSwitch(checked, onChange, enabled)
    }
}

@Composable
fun LinkLine(title: String, value: String?, icon: ImageVector? = null, color: Color = Ac.Text, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Box(Modifier.size(12.dp))
        }
        Text(title, fontSize = 16.sp, color = color, maxLines = 1, softWrap = false)
        // la valeur prend la place restante et se coupe proprement si elle est longue
        Text(
            value ?: "", fontSize = 14.sp, color = Ac.Soft, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f).padding(start = 12.dp),
        )
        Icon(AIcons.Chevron, null, tint = Ac.Soft, modifier = Modifier.size(20.dp))
    }
}

/** Choix parmi quelques valeurs (pastilles). */
@Composable
fun <T> ChoiceRow(options: List<Pair<T, String>>, selected: T, danger: T? = null, onSelect: (T) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp).clip(RoundedCornerShape(14.dp)).background(Ac.Surface2).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        options.forEach { (v, label) ->
            val on = v == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (on && v == danger) Ac.Danger.copy(alpha = 0.16f) else if (on) Ac.Surface else Color.Transparent)
                    .clickable { onSelect(v) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, fontSize = 14.sp,
                    // option risquée : toujours en rouge
                    color = if (v == danger) Ac.Danger else if (on) Ac.Text else Ac.Soft,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, description: String, tint: Color = Ac.Text, background: Color = Ac.Surface, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(background).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, description, tint = tint, modifier = Modifier.size(22.dp)) }
}

/** Appelé à chaque retour au premier plan. */
@Composable
fun LifecycleResume(onResume: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    val cb by rememberUpdatedState(onResume)
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) cb() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
}
