package com.aurora.alarm.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest
import java.security.SecureRandom

/** Réglages + mot de passe d'arrêt (jamais stocké en clair : empreinte salée). */
object AppPrefs {
    private var prefs: SharedPreferences? = null

    /** 0 = code (chiffres), 1 = mot de passe (lettres et chiffres) */
    var passwordKind by mutableIntStateOf(0)
        private set
    var hasPassword by mutableStateOf(false)
        private set
    /** Arrêt automatique de la sonnerie (minutes, 0 = jamais) */
    var autoStop by mutableIntStateOf(30)
        private set
    var snoozeMinutes by mutableIntStateOf(5)
        private set
    var gradualVolume by mutableStateOf(true)
        private set
    var forceVolume by mutableStateOf(true)
        private set
    /** 0 = système, 1 = clair, 2 = sombre */
    var themeMode by mutableIntStateOf(0)
        private set

    fun init(context: Context) {
        if (prefs != null) return
        val ctx = context.applicationContext.createDeviceProtectedStorageContext()
        runCatching { ctx.moveSharedPreferencesFrom(context.applicationContext, "settings") }
        val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        prefs = p
        passwordKind = p.getInt("kind", 0)
        hasPassword = p.getString("hash", null) != null
        autoStop = p.getInt("autoStop", 30)
        snoozeMinutes = p.getInt("snooze", 5)
        gradualVolume = p.getBoolean("gradual", true)
        forceVolume = p.getBoolean("force", true)
        themeMode = p.getInt("theme", 0)
    }

    fun changeAutoStop(v: Int) { autoStop = v; prefs?.edit()?.putInt("autoStop", v)?.apply() }
    fun changeSnooze(v: Int) { snoozeMinutes = v; prefs?.edit()?.putInt("snooze", v)?.apply() }
    fun changeGradual(v: Boolean) { gradualVolume = v; prefs?.edit()?.putBoolean("gradual", v)?.apply() }
    fun changeForce(v: Boolean) { forceVolume = v; prefs?.edit()?.putBoolean("force", v)?.apply() }
    fun changeTheme(v: Int) { themeMode = v; prefs?.edit()?.putInt("theme", v)?.apply() }

    private fun hash(salt: String, pw: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var b = (salt + pw).toByteArray(Charsets.UTF_8)
        repeat(20_000) { b = md.digest(b) }
        return b.joinToString("") { "%02x".format(it) }
    }

    fun setPassword(pw: String, kind: Int) {
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = saltBytes.joinToString("") { "%02x".format(it) }
        prefs?.edit()?.putString("salt", salt)?.putString("hash", hash(salt, pw))?.putInt("kind", kind)?.apply()
        passwordKind = kind
        hasPassword = true
    }

    fun check(pw: String): Boolean {
        val p = prefs ?: return false
        val salt = p.getString("salt", null) ?: return true
        val h = p.getString("hash", null) ?: return true
        return hash(salt, pw) == h
    }
}
