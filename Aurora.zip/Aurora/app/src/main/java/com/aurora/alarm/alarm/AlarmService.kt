package com.aurora.alarm.alarm

import com.aurora.alarm.t
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.aurora.alarm.R
import com.aurora.alarm.RingActivity
import com.aurora.alarm.data.AlarmStore
import com.aurora.alarm.data.AppPrefs
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Sonnerie en cours. Ne s'arrête que par l'écran de sonnerie (mot de passe),
 * la répétition, ou l'arrêt automatique de sécurité.
 */
class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "com.aurora.alarm.STOP"
        const val ACTION_SNOOZE = "com.aurora.alarm.SNOOZE"
        private const val CHANNEL = "ring"
        private const val CHANNEL_MISSED = "missed"
        private const val NOTIF_ID = 42

        /** Réveil qui sonne en ce moment (null = aucun), observé par l'interface. */
        val ringing = mutableStateOf<Int?>(null)

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(ACTION_STOP))
        }

        fun snooze(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(ACTION_SNOOZE))
        }

        fun ensureChannels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, t("Sonnerie", "Sound"), NotificationManager.IMPORTANCE_HIGH).apply {
                        description = t("Réveil en train de sonner", "Alarm ringing")
                        setSound(null, null)
                        enableVibration(false)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                        setBypassDnd(true)
                    }
                )
            }
            if (nm.getNotificationChannel(CHANNEL_MISSED) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_MISSED, t("Réveils manqués", "Missed alarms"), NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentId: Int = -1
    private var savedVolume: Int = -1
    private var rampStep = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AlarmStore.init(this)
        AppPrefs.init(this)
        when (intent?.action) {
            ACTION_STOP -> { finishRinging(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                if (currentId >= 0) Scheduler.snooze(this, currentId, AppPrefs.snoozeMinutes)
                finishRinging()
                return START_NOT_STICKY
            }
        }
        val id = intent?.getIntExtra(Scheduler.EXTRA_ID, -1) ?: -1
        if (id < 0) {
            if (currentId < 0) stopSelf()
            return START_NOT_STICKY
        }
        startRinging(id)
        return START_STICKY
    }

    private fun startRinging(id: Int) {
        // un nouveau réveil remplace celui qui sonnait encore
        stopSound()
        currentId = id
        ringing.value = id
        val alarm = AlarmStore.get(id)

        ensureChannels(this)
        val notif = buildNotification(alarm?.label.orEmpty())
        ServiceCompat.startForeground(
            this, NOTIF_ID, notif,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0,
        )

        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aurora:ring").apply { acquire(65 * 60 * 1000L) }

        // Écran de sonnerie (le système l'affiche aussi via la notification plein écran)
        runCatching {
            startActivity(
                Intent(this, RingActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                    .putExtra(Scheduler.EXTRA_ID, id)
            )
        }

        playSound(alarm?.ringtone)
        if (alarm?.vibrate != false) startVibration()

        val minutes = AppPrefs.autoStop
        if (minutes > 0) handler.postDelayed({ autoStopped() }, minutes * 60_000L)
    }

    private fun buildNotification(label: String): Notification {
        val full = PendingIntent.getActivity(
            this, 1,
            Intent(this, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Scheduler.EXTRA_ID, currentId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(t("Réveil · $time", "Alarm · $time"))
            .setContentText(label.ifBlank { t("Touchez pour arrêter avec votre mot de passe", "Tap to stop with your password") })
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .build()
            .apply { flags = flags or Notification.FLAG_INSISTENT or Notification.FLAG_NO_CLEAR }
    }

    private fun playSound(ringtone: String?) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        if (AppPrefs.forceVolume) {
            // volume du réveil au moins à 80 % pendant la sonnerie (rétabli ensuite)
            savedVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val target = (max * 0.8f).toInt().coerceAtLeast(1)
            if (savedVolume < target) runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0) } else savedVolume = -1
        }
        val uri: Uri = ringtone?.let { Uri.parse(it) }
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val mp = MediaPlayer()
        val ok = runCatching {
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
        }.isSuccess || runCatching {
            // sonnerie introuvable (supprimée…) : sonnerie de réveil du système
            mp.reset()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            mp.isLooping = true
            mp.prepare()
        }.isSuccess
        if (!ok) { mp.release(); return }
        player = mp
        if (AppPrefs.gradualVolume) {
            rampStep = 0
            mp.setVolume(0.08f, 0.08f)
            handler.post(object : Runnable {
                override fun run() {
                    val p = player ?: return
                    rampStep++
                    val v = (0.08f + rampStep * 0.035f).coerceAtMost(1f)
                    runCatching { p.setVolume(v, v) }
                    if (v < 1f) handler.postDelayed(this, 1000)
                }
            })
        }
        mp.start()
    }

    private fun startVibration() {
        val v = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        val pattern = longArrayOf(0, 700, 500, 700, 1200)
        v.vibrate(
            VibrationEffect.createWaveform(pattern, 0),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build(),
        )
    }

    private fun stopSound() {
        handler.removeCallbacksAndMessages(null)
        player?.let { runCatching { it.stop() }; it.release() }
        player = null
        vibrator?.cancel()
        vibrator = null
        if (savedVolume >= 0) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0) }
            savedVolume = -1
        }
    }

    private fun autoStopped() {
        // sécurité : on n'enferme personne dans une sonnerie sans fin
        val nm = getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(
            this, 2, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        nm.notify(
            43,
            NotificationCompat.Builder(this, CHANNEL_MISSED)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(t("Réveil arrêté automatiquement", "Alarm stopped automatically"))
                .setContentText(t("Il a sonné ${AppPrefs.autoStop} min sans être arrêté.", "It rang for ${AppPrefs.autoStop} min without being stopped."))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build(),
        )
        finishRinging()
    }

    private fun finishRinging() {
        stopSound()
        ringing.value = null
        currentId = -1
        wake?.let { if (it.isHeld) it.release() }
        wake = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // balayer l'appli des récents n'arrête pas la sonnerie
    }

    override fun onDestroy() {
        stopSound()
        ringing.value = null
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
