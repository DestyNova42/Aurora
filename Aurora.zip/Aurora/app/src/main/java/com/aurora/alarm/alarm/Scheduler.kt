package com.aurora.alarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.aurora.alarm.MainActivity
import com.aurora.alarm.data.Alarm
import com.aurora.alarm.data.AlarmStore
import java.time.ZonedDateTime

/** Programme les réveils auprès d'Android (réveils « horloge » : exacts, même en veille). */
object Scheduler {
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_SNOOZE = "snooze"
    private const val SNOOZE_BASE = 1_000_000

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canSchedule(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am(ctx).canScheduleExactAlarms()

    private fun operation(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra(EXTRA_ID, id).putExtra(EXTRA_SNOOZE, snooze)
            .setAction("com.aurora.alarm.FIRE.$id.$snooze")
        return PendingIntent.getBroadcast(
            ctx, if (snooze) SNOOZE_BASE + id else id, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun showIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun setAt(ctx: Context, epochMs: Long, op: PendingIntent) {
        val m = am(ctx)
        if (canSchedule(ctx)) {
            m.setAlarmClock(AlarmManager.AlarmClockInfo(epochMs, showIntent(ctx)), op)
        } else {
            // repli si l'autorisation a été retirée : réveil presque exact
            m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMs, op)
        }
    }

    fun schedule(ctx: Context, a: Alarm) {
        cancel(ctx, a.id)
        if (!a.enabled) return
        setAt(ctx, a.nextTrigger().toInstant().toEpochMilli(), operation(ctx, a.id, false))
    }

    fun cancel(ctx: Context, id: Int) {
        am(ctx).cancel(operation(ctx, id, false))
    }

    fun snooze(ctx: Context, id: Int, minutes: Int) {
        val t = ZonedDateTime.now().plusMinutes(minutes.toLong()).withSecond(0).withNano(0)
        setAt(ctx, t.toInstant().toEpochMilli(), operation(ctx, id, true))
    }

    fun cancelSnooze(ctx: Context, id: Int) {
        am(ctx).cancel(operation(ctx, id, true))
    }

    fun rescheduleAll(ctx: Context) {
        AlarmStore.init(ctx)
        AlarmStore.alarms.forEach { schedule(ctx, it) }
    }
}
