package com.aurora.alarm

import java.util.Locale

/** Langue détectée par le système : français si l'appareil est en français, anglais sinon. */
val isFrench: Boolean get() = Locale.getDefault().language == "fr"

/** Texte selon la langue du système. */
fun t(fr: String, en: String): String = if (isFrench) fr else en
