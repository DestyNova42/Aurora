# Aurora

Réveil hors ligne : la sonnerie ne s'arrête qu'avec votre code ou votre mot de passe.
Compilé en APK par GitHub Actions (fichier `.github/workflows/build.yml`).
